Contributing is welcome.
  
Use Issues for your questions such that a public FAQ may be created.

Use Issues (best) or E-mail for suggestions.
